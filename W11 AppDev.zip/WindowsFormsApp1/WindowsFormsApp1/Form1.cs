﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //Antonius Trimaryono 048
        

        MySqlConnection sqlconnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonLOGIN_Click(object sender, EventArgs e)
        {
            sqlconnect = new MySqlConnection("server=" + textBoxSERVER.Text + ";uid=" + textBoxUser.Text + ";pwd=" + textBoxPassword.Text + ";database=" + textBoxDatabase.Text);
            sqlconnect.Open();
            sqlconnect.Close();


            string pe = "select team_name,team_id from team;";
            sqlCommand = new MySqlCommand(pe, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dthome = new DataTable();
            DataTable dtaway = new DataTable();
            sqlDataAdapter.Fill(dthome);
            sqlDataAdapter.Fill(dtaway);

            comboBoxHome.DataSource = dthome;
            comboBoxHome.DisplayMember = "team_name";
            comboBoxHome.ValueMember = "team_id";

            comboBoxAway.DataSource = dtaway;
            comboBoxAway.DisplayMember = "team_name";
            comboBoxAway.ValueMember = "team_id";

            
        }

        private void dataGridViewPEPE_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBoxSERVER_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBoxHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (comboBoxHome.Text != "" && comboBoxAway.Text != "")
            {
                string pe = "select match_id, match_date, team_home, team_away from `match`";
                sqlCommand = new MySqlCommand(pe, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dtmatch = new DataTable();
                sqlDataAdapter.Fill(dtmatch);

                for (int i = 0; i < dtmatch.Rows.Count; i++)
                {
                    if (dtmatch.Rows[i][2].ToString() == comboBoxHome.SelectedValue.ToString() && dtmatch.Rows[i][3].ToString() == comboBoxAway.SelectedValue.ToString());
                    {
                        textBoxMatchID.Text = dtmatch.Rows[i][0].ToString();
                        dateTimePicker2.Text = dtmatch.Rows[i][1].ToString();
                        break;
                    }
                }
            }

            string sql = "select * from dmatch;";
            sqlCommand = new MySqlCommand(sql, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dgvkiw = new DataTable();
            sqlDataAdapter.Fill(dgvkiw);

            string sqll = "select player_id, player_name from player;";
            sqlCommand = new MySqlCommand(sqll, sqlconnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            DataTable dgvkiwkiw = new DataTable();
            sqlDataAdapter.Fill(dgvkiwkiw);

            DataTable tampil = new DataTable();
            tampil.Columns.Add("Minute");
            tampil.Columns.Add("Team Name");
            tampil.Columns.Add("Player Name");
            tampil.Columns.Add("Type");





  


            string x = "";
            string c = "";

            for (int i = 0; i < dgvkiw.Rows.Count; i++)
            {
                if (dgvkiw.Rows[i][0].ToString() == textBoxMatchID.Text)
                {
                    if (dgvkiw.Rows[i][2].ToString() == comboBoxAway.SelectedValue.ToString())
                    {
                        x = comboBoxAway.Text;
                    }
                    if (dgvkiw.Rows[i][2].ToString() == comboBoxHome.SelectedValue.ToString())
                    {
                        x = comboBoxHome.Text;
                    }

                    for (int j = 0; j < dgvkiwkiw.Rows.Count; j++)
                    {
                        c = dgvkiwkiw.Rows[j][1].ToString();
                    }
                    tampil.Rows.Add(dgvkiw.Rows[i][1].ToString(), x, c, dgvkiw.Rows[i][4].ToString());
                }
                
            }

            dataGridViewPEPE.DataSource = tampil;
        }

        private void comboBoxAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxHome.Text != "" && comboBoxAway.Text != "")
            {
                string pe = "select match_id, match_date, team_home, team_away from `match`";
                sqlCommand = new MySqlCommand(pe, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dtmatch = new DataTable();
                sqlDataAdapter.Fill(dtmatch);

                for (int i = 0; i < dtmatch.Rows.Count; i++)
                {
                    if (dtmatch.Rows[i][2].ToString() == comboBoxHome.SelectedValue.ToString() && dtmatch.Rows[i][3].ToString() == comboBoxAway.SelectedValue.ToString())
                    {
                        textBoxMatchID.Text = dtmatch.Rows[i][0].ToString();
                        dateTimePicker2.Text = dtmatch.Rows[i][1].ToString();
                        break;
                    }
                }
                DataTable tampil = new DataTable();
                tampil.Columns.Add("Minute");
                tampil.Columns.Add("Team Name");
                tampil.Columns.Add("Player Name");
                tampil.Columns.Add("Type");





                string sql = "select * from dmatch;";
                sqlCommand = new MySqlCommand(sql, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dgvkiw = new DataTable();
                sqlDataAdapter.Fill(dgvkiw);

                string sqll = "select player_id,player_name from player;";
                sqlCommand = new MySqlCommand(sqll, sqlconnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                DataTable dgvkiwkiw = new DataTable();
                sqlDataAdapter.Fill(dgvkiwkiw);


                string x = "";
                string c = "";

                for (int i = 0; i < dgvkiw.Rows.Count; i++)
                {
                    if (dgvkiw.Rows[i][0].ToString() == textBoxMatchID.Text)
                    {
                        if (dgvkiw.Rows[i][2].ToString() == comboBoxAway.SelectedValue.ToString())
                        {
                            x = comboBoxAway.Text;
                        }
                        if (dgvkiw.Rows[i][2].ToString() == comboBoxHome.SelectedValue.ToString())
                        {
                            x = comboBoxHome.Text;
                        }

                        for (int j = 0; j < dgvkiwkiw.Rows.Count; j++)
                        {
                            c = dgvkiwkiw.Rows[j][1].ToString();
                        }
                        tampil.Rows.Add(dgvkiw.Rows[i][1].ToString(), x, c, dgvkiw.Rows[i][4].ToString());
                    }

                }

                dataGridViewPEPE.DataSource = tampil;


            }
        }
    }
}
