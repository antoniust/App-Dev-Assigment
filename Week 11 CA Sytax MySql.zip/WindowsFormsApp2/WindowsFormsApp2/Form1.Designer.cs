﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewPEPE = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPEPE)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewPEPE
            // 
            this.dataGridViewPEPE.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewPEPE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPEPE.Location = new System.Drawing.Point(60, 21);
            this.dataGridViewPEPE.Name = "dataGridViewPEPE";
            this.dataGridViewPEPE.RowHeadersVisible = false;
            this.dataGridViewPEPE.RowHeadersWidth = 82;
            this.dataGridViewPEPE.RowTemplate.Height = 33;
            this.dataGridViewPEPE.Size = new System.Drawing.Size(1845, 843);
            this.dataGridViewPEPE.TabIndex = 0;
            this.dataGridViewPEPE.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPEPE_CellContentClick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1971, 935);
            this.Controls.Add(this.dataGridViewPEPE);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPEPE)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewPEPE;
    }
}

