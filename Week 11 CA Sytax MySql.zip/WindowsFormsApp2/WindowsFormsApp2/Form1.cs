﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp2

{
    public partial class Form1 : Form
    {
        MySqlConnection sqlconnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqldataadapter;
       


        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridViewPEPE_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {


            sqlconnect = new MySqlConnection(";server=localhost;uid=student;pwd=isbmantap;database=premier_league;");
            sqlconnect.Open();
            sqlconnect.Close();

            //Menampilkan Deskripsi dari playing_pos apabila dalam table hanya D,F,M,G
            string sql = "SELECT player_id as `Player ID`, team_name ,player_name as `Player Name`,IF(playing_pos = 'F','Forward',IF(playing_pos = 'M','Midfielder',IF(playing_pos = 'G','Goalkeeper',IF(playing_pos = 'D','Defender','Unknown')))) as `Player Position` FROM player p, team t WHERE p.team_id = t.team_id;";
            string sqll = "SELECT team_name,manager_name FROM team t, manager m WHERE t.manager_id = m.manager_id;";
            //Menampilkan hasil dmatch team gome dan team away menggunakan nama team bukan idnya dari table dmatch
            string sqlll = "SELECT match_id, match_date , t.team_name as `Team Home`, t2.team_name as `Team Away` FROM `match` m, team t, team t2 WHERE m.team_home = t.team_id AND t2.team_id = m.team_away;";
            //Menampilkan Isi dari nama manager, asistan manager dan captain menggunakan namanya bukan idnya dari table team
            string sqllll = "SELECT m.manager_name, m2.manager_name as `manager assistane`, p.player_name as `Captain` FROM manager m,manager m2,team t, player p WHERE m.manager_id = t.manager_id AND m2.manager_id = t.assmanager_id AND p.player_id = t.captain_id;";
            sqlCommand = new MySqlCommand(sqllll,sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlCommand);
            DataTable dtTeam = new DataTable();
            sqldataadapter.Fill(dtTeam);

            dataGridViewPEPE.DataSource = dtTeam;
        }
    }
}
