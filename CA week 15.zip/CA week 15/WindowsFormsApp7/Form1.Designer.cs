﻿namespace WindowsFormsApp7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb_teamHome = new System.Windows.Forms.ComboBox();
            this.cb_TeamAway = new System.Windows.Forms.ComboBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonCheck = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dgvPEPE = new System.Windows.Forms.DataGridView();
            this.lblManagerHome = new System.Windows.Forms.Label();
            this.lblcaptainHome = new System.Windows.Forms.Label();
            this.lblManagerAway = new System.Windows.Forms.Label();
            this.lblCaptainAway = new System.Windows.Forms.Label();
            this.lblStadium = new System.Windows.Forms.Label();
            this.labelCapacity = new System.Windows.Forms.Label();
            this.lblTanggal = new System.Windows.Forms.Label();
            this.lblSKORR = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPEPE)).BeginInit();
            this.SuspendLayout();
            // 
            // cb_teamHome
            // 
            this.cb_teamHome.FormattingEnabled = true;
            this.cb_teamHome.Location = new System.Drawing.Point(151, 86);
            this.cb_teamHome.Name = "cb_teamHome";
            this.cb_teamHome.Size = new System.Drawing.Size(297, 33);
            this.cb_teamHome.TabIndex = 0;
            this.cb_teamHome.SelectedIndexChanged += new System.EventHandler(this.cb_teamHome_SelectedIndexChanged);
            // 
            // cb_TeamAway
            // 
            this.cb_TeamAway.FormattingEnabled = true;
            this.cb_TeamAway.Location = new System.Drawing.Point(921, 86);
            this.cb_TeamAway.Name = "cb_TeamAway";
            this.cb_TeamAway.Size = new System.Drawing.Size(297, 33);
            this.cb_TeamAway.TabIndex = 1;
            this.cb_TeamAway.SelectedIndexChanged += new System.EventHandler(this.cb_TeamAway_SelectedIndexChanged);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(151, 171);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(109, 25);
            this.lbl1.TabIndex = 2;
            this.lbl1.Text = "Manager :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(162, 225);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 25);
            this.label1.TabIndex = 3;
            this.label1.Text = "Captain :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(916, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 25);
            this.label2.TabIndex = 4;
            this.label2.Text = "Manager :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(916, 225);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Captain :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(458, 296);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "Stadium :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(452, 349);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 25);
            this.label5.TabIndex = 7;
            this.label5.Text = "Capacity :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(0, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // buttonCheck
            // 
            this.buttonCheck.Location = new System.Drawing.Point(636, 432);
            this.buttonCheck.Name = "buttonCheck";
            this.buttonCheck.Size = new System.Drawing.Size(118, 42);
            this.buttonCheck.TabIndex = 9;
            this.buttonCheck.Text = "Check";
            this.buttonCheck.UseVisualStyleBackColor = true;
            this.buttonCheck.Click += new System.EventHandler(this.buttonCheck_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(458, 508);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Tanggal :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(492, 550);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 25);
            this.label7.TabIndex = 11;
            this.label7.Text = "Skor :";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // dgvPEPE
            // 
            this.dgvPEPE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPEPE.Location = new System.Drawing.Point(101, 666);
            this.dgvPEPE.Name = "dgvPEPE";
            this.dgvPEPE.RowHeadersWidth = 82;
            this.dgvPEPE.RowTemplate.Height = 33;
            this.dgvPEPE.Size = new System.Drawing.Size(1155, 417);
            this.dgvPEPE.TabIndex = 12;
            this.dgvPEPE.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblManagerHome
            // 
            this.lblManagerHome.AutoSize = true;
            this.lblManagerHome.Location = new System.Drawing.Point(267, 170);
            this.lblManagerHome.Name = "lblManagerHome";
            this.lblManagerHome.Size = new System.Drawing.Size(70, 25);
            this.lblManagerHome.TabIndex = 13;
            this.lblManagerHome.Text = "label8";
            // 
            // lblcaptainHome
            // 
            this.lblcaptainHome.AutoSize = true;
            this.lblcaptainHome.Location = new System.Drawing.Point(267, 225);
            this.lblcaptainHome.Name = "lblcaptainHome";
            this.lblcaptainHome.Size = new System.Drawing.Size(70, 25);
            this.lblcaptainHome.TabIndex = 14;
            this.lblcaptainHome.Text = "label9";
            // 
            // lblManagerAway
            // 
            this.lblManagerAway.AutoSize = true;
            this.lblManagerAway.Location = new System.Drawing.Point(1031, 171);
            this.lblManagerAway.Name = "lblManagerAway";
            this.lblManagerAway.Size = new System.Drawing.Size(70, 25);
            this.lblManagerAway.TabIndex = 15;
            this.lblManagerAway.Text = "label8";
            // 
            // lblCaptainAway
            // 
            this.lblCaptainAway.AutoSize = true;
            this.lblCaptainAway.Location = new System.Drawing.Point(1020, 225);
            this.lblCaptainAway.Name = "lblCaptainAway";
            this.lblCaptainAway.Size = new System.Drawing.Size(70, 25);
            this.lblCaptainAway.TabIndex = 16;
            this.lblCaptainAway.Text = "label9";
            // 
            // lblStadium
            // 
            this.lblStadium.AutoSize = true;
            this.lblStadium.Location = new System.Drawing.Point(566, 296);
            this.lblStadium.Name = "lblStadium";
            this.lblStadium.Size = new System.Drawing.Size(70, 25);
            this.lblStadium.TabIndex = 17;
            this.lblStadium.Text = "label9";
            // 
            // labelCapacity
            // 
            this.labelCapacity.AutoSize = true;
            this.labelCapacity.Location = new System.Drawing.Point(566, 349);
            this.labelCapacity.Name = "labelCapacity";
            this.labelCapacity.Size = new System.Drawing.Size(70, 25);
            this.labelCapacity.TabIndex = 18;
            this.labelCapacity.Text = "label9";
            // 
            // lblTanggal
            // 
            this.lblTanggal.AutoSize = true;
            this.lblTanggal.Location = new System.Drawing.Point(566, 508);
            this.lblTanggal.Name = "lblTanggal";
            this.lblTanggal.Size = new System.Drawing.Size(70, 25);
            this.lblTanggal.TabIndex = 19;
            this.lblTanggal.Text = "label9";
            this.lblTanggal.Click += new System.EventHandler(this.lblTanggal_Click);
            // 
            // lblSKORR
            // 
            this.lblSKORR.AutoSize = true;
            this.lblSKORR.Location = new System.Drawing.Point(566, 550);
            this.lblSKORR.Name = "lblSKORR";
            this.lblSKORR.Size = new System.Drawing.Size(70, 25);
            this.lblSKORR.TabIndex = 20;
            this.lblSKORR.Text = "label9";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1391, 1153);
            this.Controls.Add(this.lblSKORR);
            this.Controls.Add(this.lblTanggal);
            this.Controls.Add(this.labelCapacity);
            this.Controls.Add(this.lblStadium);
            this.Controls.Add(this.lblCaptainAway);
            this.Controls.Add(this.lblManagerAway);
            this.Controls.Add(this.lblcaptainHome);
            this.Controls.Add(this.lblManagerHome);
            this.Controls.Add(this.dgvPEPE);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonCheck);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.cb_TeamAway);
            this.Controls.Add(this.cb_teamHome);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPEPE)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb_teamHome;
        private System.Windows.Forms.ComboBox cb_TeamAway;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonCheck;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dgvPEPE;
        private System.Windows.Forms.Label lblManagerHome;
        private System.Windows.Forms.Label lblcaptainHome;
        private System.Windows.Forms.Label lblManagerAway;
        private System.Windows.Forms.Label lblCaptainAway;
        private System.Windows.Forms.Label lblStadium;
        private System.Windows.Forms.Label labelCapacity;
        private System.Windows.Forms.Label lblTanggal;
        private System.Windows.Forms.Label lblSKORR;
    }
}

