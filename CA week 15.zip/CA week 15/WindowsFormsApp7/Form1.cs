﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace WindowsFormsApp7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string sqlQuery = "";
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;
        DataTable dtStadium = new DataTable();
        DataTable dtTeamH = new DataTable();
        DataTable dtTeamA = new DataTable();
        DataTable inputan = new DataTable();
        DataTable dtManager = new DataTable();  
        DataTable WayaheTampil = new DataTable();

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection($"server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            sqlConnect.Open();
            sqlConnect.Close();
            sqlQuery = $"SELECT team_name, team_id FROM team;";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtTeamA);
            sqlDataAdapter.Fill(dtTeamH);
            cb_teamHome.DataSource = dtTeamH;
            cb_TeamAway.DataSource = dtTeamA;

            WayaheTampil.Columns.Add("Minute");
            WayaheTampil.Columns.Add("Player Name 1");
            WayaheTampil.Columns.Add("Tipe 1");
            WayaheTampil.Columns.Add("Player Name 2");
            WayaheTampil.Columns.Add("Type 2");




            cb_TeamAway.ValueMember = "team_id";
            cb_TeamAway.DisplayMember = "team_name";
            cb_teamHome.ValueMember = "team_id";
            cb_teamHome.DisplayMember = "team_name";


        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void cb_teamHome_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtManager = new DataTable();
            if (cb_teamHome.SelectedItem != cb_TeamAway.SelectedItem)
            {
                dgvPEPE.DataSource = inputan;
                sqlQuery = "SELECT manager.manager_name, player.player_name FROM team left join manager on team.manager_id = manager.manager_id left join player on player.player_id = team.captain_id WHERE team.team_id = '" + cb_teamHome.SelectedValue + "';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtManager);
                if (dtManager.Rows.Count != 0)
                {
                    lblManagerHome.Text = dtManager.Rows[0][0].ToString();
                    lblcaptainHome.Text = dtManager.Rows[0][1].ToString();
                }


                sqlQuery = $"SELECT team.home_stadium, team.city,team.capacity from team WHERE team.team_id = '{cb_teamHome.SelectedValue}';";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtStadium = new DataTable();
                sqlDataAdapter.Fill(dtStadium);
                if (dtStadium.Rows.Count != 0)
                {
                    lblStadium.Text = dtStadium.Rows[0][0].ToString();
                    labelCapacity.Text = dtStadium.Rows[0][2].ToString();
                }
               
            }
            else
            {
                MessageBox.Show("Team Gaboleh Sama");

            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cb_TeamAway_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtManager = new DataTable();
            if (cb_teamHome.SelectedItem != cb_TeamAway.SelectedItem)
            {

                dgvPEPE.DataSource = inputan;
                sqlQuery = $"SELECT manager.manager_name, player.player_name FROM team left join manager on team.manager_id = manager.manager_id left join player on player.player_id = team.captain_id WHERE team.team_id = '{cb_TeamAway.SelectedValue}'";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                sqlDataAdapter.Fill(dtManager);
                if (dtManager.Rows.Count != 0)
                {
                    lblManagerAway.Text = dtManager.Rows[0][0].ToString();
                    lblCaptainAway.Text = dtManager.Rows[0][1].ToString();
                }
                
            }
            else
            {
                MessageBox.Show("Team Gaboleh Sama");

            }
        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            string matchID;
            DataTable dtMatch = new DataTable();    
            DataTable dtWayaheMatchTampil = new DataTable();
            sqlQuery = $"SELECT match_id, date_format(match_date,'%d %M %Y') as match_date,concat(match.goal_home, '-', match.goal_away) from `match` where team_home ='{cb_teamHome.SelectedValue}' and team_away ='{cb_TeamAway.SelectedValue}';";
            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            dtMatch = new DataTable();
            sqlDataAdapter.Fill(dtMatch);
            if (dtMatch.Rows.Count != 0)
            {
                lblTanggal.Text = dtMatch.Rows[0][1].ToString();
                lblSKORR.Text = dtMatch.Rows[0][2].ToString();

                matchID = dtMatch.Rows[0][0].ToString();
                sqlQuery = $"SELECT dmatch.minute as Minute, if(dmatch.team_id = '{cb_teamHome.SelectedValue}', player.player_name, ' ') as 'Player Name 1', if(dmatch.team_id = '{cb_teamHome.SelectedValue}', if(dmatch.type = 'GO', 'Goal', if(dmatch.type = 'GP', 'Goal Penalty', if (dmatch.type = 'GW', 'Own Goal', if(dmatch.type = 'CR', 'Red Card', if(dmatch.type = 'CY', 'Yellow Card','Penalty Miss'))))), ' ') as 'Tipe 1', if(dmatch.team_id = '{cb_TeamAway.SelectedValue}', player.player_name, ' ') as 'Player Name 2', if(dmatch.team_id = '{cb_TeamAway.SelectedValue}', if(dmatch.type = 'GO', 'Goal', if(dmatch.type = 'GP', 'Goal Penalty', if (dmatch.type = 'GW', 'Own Goal', if(dmatch.type = 'CR', 'Red Card', if(dmatch.type = 'CY', 'Yellow Card','Penalty Miss'))))), ' ') as 'Type 2' from dmatch, player where dmatch.player_id = player.player_id && dmatch.match_id = {matchID};";
                sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
                sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
                dtWayaheMatchTampil = new DataTable();
                sqlDataAdapter.Fill(dtWayaheMatchTampil);
                dgvPEPE.DataSource = dtWayaheMatchTampil;

            }
        }

        private void lblTanggal_Click(object sender, EventArgs e)
        {

        }
    }
}
