﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect; //menyambungkan mysql
        MySqlCommand SqlCommand; //menjalankan querry
        MySqlDataAdapter SqlDataAdapter; //ketika menggunakan DQL, menampung hasil data quarry


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void buttonLOGIN_Click(object sender, EventArgs e)
        {
            sqlConnect = new MySqlConnection("server=10.10.10.136;" + "uid=" +textBoxUSERNAME.Text +";"+ "pwd=" +textBoxPW.Text+";" + "database= "+textBoxDATABASE.Text+";");

            sqlConnect.Open();
            MessageBox.Show("");
            sqlConnect.Close();
            string sqlQuery = "SELECT * FROM player";

            SqlCommand = new MySqlCommand(sqlQuery,sqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);

            DataTable dtPlayer = new DataTable();
            SqlDataAdapter.Fill(dtPlayer);
            dataGridView1.DataSource = dtPlayer;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //nam_mahasiswa VARCHAR(30)
            //nama_mahasiswa VARCHAR(50)
            //kota_asal VARCHAR(50)



            string sqlQuery = "INSERT INTO mahasiswa VALUE ('" + textBoxNIM.Text + "','" + textBoxNAMA.Text + "','" + textBoxKota.Text + "')";
            SqlCommand = new MySqlCommand( sqlQuery,sqlConnect);

            sqlConnect.Open();
            SqlCommand.ExecuteNonQuery();
            sqlConnect.Close();
        }

        private void buttonREF_Click(object sender, EventArgs e)
        {
            string sqlQuery = "SELECT * FROM mahasiswa";

            SqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            SqlDataAdapter = new MySqlDataAdapter(SqlCommand);

            DataTable dtMhs = new DataTable();
            SqlDataAdapter.Fill(dtMhs);
            dataGridViewMhs.DataSource = dtMhs;
        }
    }
}
