﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelUSERNAME = new System.Windows.Forms.Label();
            this.labelPWLOGIN = new System.Windows.Forms.Label();
            this.textBoxUSERNAME = new System.Windows.Forms.TextBox();
            this.textBoxPW = new System.Windows.Forms.TextBox();
            this.textBoxDATABASE = new System.Windows.Forms.TextBox();
            this.labelDBAS = new System.Windows.Forms.Label();
            this.buttonLOGIN = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxKota = new System.Windows.Forms.TextBox();
            this.textBoxNAMA = new System.Windows.Forms.TextBox();
            this.textBoxNIM = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.buttonREF = new System.Windows.Forms.Button();
            this.dataGridViewMhs = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMhs)).BeginInit();
            this.SuspendLayout();
            // 
            // labelUSERNAME
            // 
            this.labelUSERNAME.AutoSize = true;
            this.labelUSERNAME.Location = new System.Drawing.Point(152, 270);
            this.labelUSERNAME.Name = "labelUSERNAME";
            this.labelUSERNAME.Size = new System.Drawing.Size(122, 25);
            this.labelUSERNAME.TabIndex = 0;
            this.labelUSERNAME.Text = "Username :";
            // 
            // labelPWLOGIN
            // 
            this.labelPWLOGIN.AutoSize = true;
            this.labelPWLOGIN.Location = new System.Drawing.Point(152, 322);
            this.labelPWLOGIN.Name = "labelPWLOGIN";
            this.labelPWLOGIN.Size = new System.Drawing.Size(118, 25);
            this.labelPWLOGIN.TabIndex = 1;
            this.labelPWLOGIN.Text = "Password :";
            // 
            // textBoxUSERNAME
            // 
            this.textBoxUSERNAME.Location = new System.Drawing.Point(317, 267);
            this.textBoxUSERNAME.Name = "textBoxUSERNAME";
            this.textBoxUSERNAME.Size = new System.Drawing.Size(173, 31);
            this.textBoxUSERNAME.TabIndex = 2;
            // 
            // textBoxPW
            // 
            this.textBoxPW.Location = new System.Drawing.Point(317, 319);
            this.textBoxPW.Name = "textBoxPW";
            this.textBoxPW.Size = new System.Drawing.Size(173, 31);
            this.textBoxPW.TabIndex = 3;
            // 
            // textBoxDATABASE
            // 
            this.textBoxDATABASE.Location = new System.Drawing.Point(317, 369);
            this.textBoxDATABASE.Name = "textBoxDATABASE";
            this.textBoxDATABASE.Size = new System.Drawing.Size(173, 31);
            this.textBoxDATABASE.TabIndex = 4;
            // 
            // labelDBAS
            // 
            this.labelDBAS.AutoSize = true;
            this.labelDBAS.Location = new System.Drawing.Point(152, 372);
            this.labelDBAS.Name = "labelDBAS";
            this.labelDBAS.Size = new System.Drawing.Size(116, 25);
            this.labelDBAS.TabIndex = 5;
            this.labelDBAS.Text = "Database :";
            // 
            // buttonLOGIN
            // 
            this.buttonLOGIN.Location = new System.Drawing.Point(89, 484);
            this.buttonLOGIN.Name = "buttonLOGIN";
            this.buttonLOGIN.Size = new System.Drawing.Size(492, 260);
            this.buttonLOGIN.TabIndex = 6;
            this.buttonLOGIN.Text = "MLEBU";
            this.buttonLOGIN.UseVisualStyleBackColor = true;
            this.buttonLOGIN.Click += new System.EventHandler(this.buttonLOGIN_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(1311, 633);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.Size = new System.Drawing.Size(1195, 215);
            this.dataGridView1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(681, 375);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Kota Asal :";
            // 
            // textBoxKota
            // 
            this.textBoxKota.Location = new System.Drawing.Point(846, 372);
            this.textBoxKota.Name = "textBoxKota";
            this.textBoxKota.Size = new System.Drawing.Size(173, 31);
            this.textBoxKota.TabIndex = 12;
            // 
            // textBoxNAMA
            // 
            this.textBoxNAMA.Location = new System.Drawing.Point(846, 322);
            this.textBoxNAMA.Name = "textBoxNAMA";
            this.textBoxNAMA.Size = new System.Drawing.Size(173, 31);
            this.textBoxNAMA.TabIndex = 11;
            // 
            // textBoxNIM
            // 
            this.textBoxNIM.Location = new System.Drawing.Point(846, 270);
            this.textBoxNIM.Name = "textBoxNIM";
            this.textBoxNIM.Size = new System.Drawing.Size(173, 31);
            this.textBoxNIM.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(681, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 25);
            this.label2.TabIndex = 9;
            this.label2.Text = "Nama :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(681, 273);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "NIM :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(626, 484);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(492, 260);
            this.button1.TabIndex = 14;
            this.button1.Text = "INSERT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonREF
            // 
            this.buttonREF.Location = new System.Drawing.Point(626, 750);
            this.buttonREF.Name = "buttonREF";
            this.buttonREF.Size = new System.Drawing.Size(492, 98);
            this.buttonREF.TabIndex = 15;
            this.buttonREF.Text = "FANTA";
            this.buttonREF.UseVisualStyleBackColor = true;
            this.buttonREF.Click += new System.EventHandler(this.buttonREF_Click);
            // 
            // dataGridViewMhs
            // 
            this.dataGridViewMhs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMhs.Location = new System.Drawing.Point(1311, 319);
            this.dataGridViewMhs.Name = "dataGridViewMhs";
            this.dataGridViewMhs.RowHeadersWidth = 82;
            this.dataGridViewMhs.RowTemplate.Height = 33;
            this.dataGridViewMhs.Size = new System.Drawing.Size(1195, 215);
            this.dataGridViewMhs.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2660, 1273);
            this.Controls.Add(this.dataGridViewMhs);
            this.Controls.Add(this.buttonREF);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxKota);
            this.Controls.Add(this.textBoxNAMA);
            this.Controls.Add(this.textBoxNIM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.buttonLOGIN);
            this.Controls.Add(this.labelDBAS);
            this.Controls.Add(this.textBoxDATABASE);
            this.Controls.Add(this.textBoxPW);
            this.Controls.Add(this.textBoxUSERNAME);
            this.Controls.Add(this.labelPWLOGIN);
            this.Controls.Add(this.labelUSERNAME);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMhs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelUSERNAME;
        private System.Windows.Forms.Label labelPWLOGIN;
        private System.Windows.Forms.TextBox textBoxUSERNAME;
        private System.Windows.Forms.TextBox textBoxPW;
        private System.Windows.Forms.TextBox textBoxDATABASE;
        private System.Windows.Forms.Label labelDBAS;
        private System.Windows.Forms.Button buttonLOGIN;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxKota;
        private System.Windows.Forms.TextBox textBoxNAMA;
        private System.Windows.Forms.TextBox textBoxNIM;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button buttonREF;
        private System.Windows.Forms.DataGridView dataGridViewMhs;
    }
}

