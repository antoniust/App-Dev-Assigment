﻿namespace WindowsFormsApp2
{
    partial class form_Remove
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxRmvID = new System.Windows.Forms.TextBox();
            this.textBoxRmvHarga = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonRMV = new System.Windows.Forms.Button();
            this.labelKACAWW = new System.Windows.Forms.Label();
            this.comBoxRemoveNAMA = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // textBoxRmvID
            // 
            this.textBoxRmvID.Enabled = false;
            this.textBoxRmvID.Location = new System.Drawing.Point(703, 316);
            this.textBoxRmvID.Name = "textBoxRmvID";
            this.textBoxRmvID.Size = new System.Drawing.Size(256, 31);
            this.textBoxRmvID.TabIndex = 14;
            // 
            // textBoxRmvHarga
            // 
            this.textBoxRmvHarga.Enabled = false;
            this.textBoxRmvHarga.Location = new System.Drawing.Point(703, 253);
            this.textBoxRmvHarga.Name = "textBoxRmvHarga";
            this.textBoxRmvHarga.Size = new System.Drawing.Size(256, 31);
            this.textBoxRmvHarga.TabIndex = 13;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(505, 319);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 12;
            this.label2.Text = "ID Produk";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(505, 256);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 11;
            this.label1.Text = "Harga";
            // 
            // buttonRMV
            // 
            this.buttonRMV.Location = new System.Drawing.Point(553, 450);
            this.buttonRMV.Name = "buttonRMV";
            this.buttonRMV.Size = new System.Drawing.Size(363, 160);
            this.buttonRMV.TabIndex = 9;
            this.buttonRMV.Text = "REMOVE";
            this.buttonRMV.UseVisualStyleBackColor = true;
            this.buttonRMV.Click += new System.EventHandler(this.buttonRMV_Click);
            // 
            // labelKACAWW
            // 
            this.labelKACAWW.AutoSize = true;
            this.labelKACAWW.Location = new System.Drawing.Point(500, 196);
            this.labelKACAWW.Name = "labelKACAWW";
            this.labelKACAWW.Size = new System.Drawing.Size(142, 25);
            this.labelKACAWW.TabIndex = 8;
            this.labelKACAWW.Text = "Nama Produk";
            // 
            // comBoxRemoveNAMA
            // 
            this.comBoxRemoveNAMA.FormattingEnabled = true;
            this.comBoxRemoveNAMA.Location = new System.Drawing.Point(703, 193);
            this.comBoxRemoveNAMA.Name = "comBoxRemoveNAMA";
            this.comBoxRemoveNAMA.Size = new System.Drawing.Size(256, 33);
            this.comBoxRemoveNAMA.TabIndex = 15;
            this.comBoxRemoveNAMA.SelectedIndexChanged += new System.EventHandler(this.comBoxRemoveNAMA_SelectedIndexChanged);
            // 
            // form_Remove
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1458, 800);
            this.Controls.Add(this.comBoxRemoveNAMA);
            this.Controls.Add(this.textBoxRmvID);
            this.Controls.Add(this.textBoxRmvHarga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonRMV);
            this.Controls.Add(this.labelKACAWW);
            this.Name = "form_Remove";
            this.Text = "form_Remove";
            this.Load += new System.EventHandler(this.form_Remove_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBoxRmvID;
        private System.Windows.Forms.TextBox textBoxRmvHarga;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonRMV;
        private System.Windows.Forms.Label labelKACAWW;
        private System.Windows.Forms.ComboBox comBoxRemoveNAMA;
    }
}