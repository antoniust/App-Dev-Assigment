﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonOPENFORM = new System.Windows.Forms.Button();
            this.textBoxKACAWW = new System.Windows.Forms.TextBox();
            this.buttonKACAWW = new System.Windows.Forms.Button();
            this.labelRANDOM = new System.Windows.Forms.Label();
            this.dgwMENU = new System.Windows.Forms.DataGridView();
            this.REMOVE = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgwMENU)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonOPENFORM
            // 
            this.buttonOPENFORM.Location = new System.Drawing.Point(255, 618);
            this.buttonOPENFORM.Name = "buttonOPENFORM";
            this.buttonOPENFORM.Size = new System.Drawing.Size(354, 174);
            this.buttonOPENFORM.TabIndex = 0;
            this.buttonOPENFORM.Text = "Add Product";
            this.buttonOPENFORM.UseVisualStyleBackColor = true;
            this.buttonOPENFORM.Click += new System.EventHandler(this.buttonOPENFORM_Click);
            // 
            // textBoxKACAWW
            // 
            this.textBoxKACAWW.Location = new System.Drawing.Point(1404, 285);
            this.textBoxKACAWW.Name = "textBoxKACAWW";
            this.textBoxKACAWW.Size = new System.Drawing.Size(100, 31);
            this.textBoxKACAWW.TabIndex = 1;
            // 
            // buttonKACAWW
            // 
            this.buttonKACAWW.Location = new System.Drawing.Point(1296, 351);
            this.buttonKACAWW.Name = "buttonKACAWW";
            this.buttonKACAWW.Size = new System.Drawing.Size(313, 153);
            this.buttonKACAWW.TabIndex = 2;
            this.buttonKACAWW.Text = "KIRIM";
            this.buttonKACAWW.UseVisualStyleBackColor = true;
            this.buttonKACAWW.Click += new System.EventHandler(this.buttonKACAWW_Click);
            // 
            // labelRANDOM
            // 
            this.labelRANDOM.AutoSize = true;
            this.labelRANDOM.Location = new System.Drawing.Point(1420, 236);
            this.labelRANDOM.Name = "labelRANDOM";
            this.labelRANDOM.Size = new System.Drawing.Size(70, 25);
            this.labelRANDOM.TabIndex = 3;
            this.labelRANDOM.Text = "label1";
            // 
            // dgwMENU
            // 
            this.dgwMENU.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgwMENU.Location = new System.Drawing.Point(255, 192);
            this.dgwMENU.Name = "dgwMENU";
            this.dgwMENU.RowHeadersWidth = 82;
            this.dgwMENU.RowTemplate.Height = 33;
            this.dgwMENU.Size = new System.Drawing.Size(859, 402);
            this.dgwMENU.TabIndex = 4;
            // 
            // REMOVE
            // 
            this.REMOVE.Location = new System.Drawing.Point(651, 618);
            this.REMOVE.Name = "REMOVE";
            this.REMOVE.Size = new System.Drawing.Size(354, 174);
            this.REMOVE.TabIndex = 5;
            this.REMOVE.Text = "REMOVE";
            this.REMOVE.UseVisualStyleBackColor = true;
            this.REMOVE.Click += new System.EventHandler(this.REMOVE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1676, 939);
            this.Controls.Add(this.REMOVE);
            this.Controls.Add(this.dgwMENU);
            this.Controls.Add(this.labelRANDOM);
            this.Controls.Add(this.buttonKACAWW);
            this.Controls.Add(this.textBoxKACAWW);
            this.Controls.Add(this.buttonOPENFORM);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgwMENU)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOPENFORM;
        private System.Windows.Forms.TextBox textBoxKACAWW;
        private System.Windows.Forms.Button buttonKACAWW;
        private System.Windows.Forms.Label labelRANDOM;
        private System.Windows.Forms.DataGridView dgwMENU;
        private System.Windows.Forms.Button REMOVE;
    }
}

