﻿namespace WindowsFormsApp2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelKACAWW = new System.Windows.Forms.Label();
            this.buttonRANDOM = new System.Windows.Forms.Button();
            this.textBoxNP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxHarga = new System.Windows.Forms.TextBox();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelKACAWW
            // 
            this.labelKACAWW.AutoSize = true;
            this.labelKACAWW.Location = new System.Drawing.Point(557, 181);
            this.labelKACAWW.Name = "labelKACAWW";
            this.labelKACAWW.Size = new System.Drawing.Size(142, 25);
            this.labelKACAWW.TabIndex = 0;
            this.labelKACAWW.Text = "Nama Produk";
            // 
            // buttonRANDOM
            // 
            this.buttonRANDOM.Location = new System.Drawing.Point(610, 435);
            this.buttonRANDOM.Name = "buttonRANDOM";
            this.buttonRANDOM.Size = new System.Drawing.Size(363, 160);
            this.buttonRANDOM.TabIndex = 2;
            this.buttonRANDOM.Text = "buttonRANDOM";
            this.buttonRANDOM.UseVisualStyleBackColor = true;
            this.buttonRANDOM.Click += new System.EventHandler(this.buttonRANDOM_Click);
            // 
            // textBoxNP
            // 
            this.textBoxNP.Location = new System.Drawing.Point(760, 175);
            this.textBoxNP.Name = "textBoxNP";
            this.textBoxNP.Size = new System.Drawing.Size(256, 31);
            this.textBoxNP.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(562, 241);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "Harga";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(562, 304);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "ID Produk";
            // 
            // textBoxHarga
            // 
            this.textBoxHarga.Location = new System.Drawing.Point(760, 238);
            this.textBoxHarga.Name = "textBoxHarga";
            this.textBoxHarga.Size = new System.Drawing.Size(256, 31);
            this.textBoxHarga.TabIndex = 6;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(760, 301);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(256, 31);
            this.textBoxID.TabIndex = 7;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1650, 1008);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.textBoxHarga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNP);
            this.Controls.Add(this.buttonRANDOM);
            this.Controls.Add(this.labelKACAWW);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelKACAWW;
        private System.Windows.Forms.Button buttonRANDOM;
        private System.Windows.Forms.TextBox textBoxNP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxHarga;
        private System.Windows.Forms.TextBox textBoxID;
    }
}