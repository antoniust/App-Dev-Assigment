﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form

    {
        DataTable dtmenu = new DataTable();
        Form2 form2;
        form_Remove form_Remove_;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            form2 = new Form2(this);
            form_Remove_ = new form_Remove(this, dtmenu);


            dtmenu.Columns.Add("ID Produk");
            dtmenu.Columns.Add("Nama Produk");
            dtmenu.Columns.Add("Harga");

            dtmenu.Rows.Add("001", "Nasi Goreng", "25000");
            dtmenu.Rows.Add("002", "Nasi Ayam Sayur", "25000");
            dtmenu.Rows.Add("003", "Nasi Ayam Special", "28000");

            dgwMENU.DataSource = dtmenu;
            

        }

        private void buttonOPENFORM_Click(object sender, EventArgs e)
        {
            //form2.ShowDialog();
            form2.Show();
        }

        private void buttonKACAWW_Click(object sender, EventArgs e)
        {
            form2.ShowDialog();
            form2.setLabelCHanged(textBoxKACAWW.Text);
        }

        public void setLabelRANDOM(int _number) 
        { 
            labelRANDOM.Text = _number.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public void setdgw(string _nama, string _harga, string _ID) 
        { 
            dgwMENU.DataSource = dtmenu;

            dtmenu.Rows.Add(_ID, _nama, _harga);
            
        }

        private void REMOVE_Click(object sender, EventArgs e)
        {
            form_Remove_.ShowDialog();
             
        }
        public void setDelete(string _id) 
        { 

            foreach ( DataRow row in dtmenu.Rows) 
            { 
                if (row[0].ToString() == _id)
                {
                    dtmenu.Rows.Remove(row);
                    break;
                }
            }
            //foreach (DataRow row in dtmenu.Rows) 
            //{ 
            //    if (_id.Equals(row["ID Produk"])) 
            //    { 
            //        dtmenu.Rows.Remove(row);
            //    }
            //}
        }
    }
}
