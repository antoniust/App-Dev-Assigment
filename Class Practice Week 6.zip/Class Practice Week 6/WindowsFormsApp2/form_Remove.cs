﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class form_Remove : Form
    {
        Form1 form1;
        DataTable dtMenu = new DataTable();
        public form_Remove(Form1 _form1, DataTable dt)
        {
            InitializeComponent();
            form1 = (Form1)_form1;
            dtMenu = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void form_Remove_Load(object sender, EventArgs e)
        {
            
            comBoxRemoveNAMA.DataSource = dtMenu;
            comBoxRemoveNAMA.DisplayMember = "Nama Produk";
            comBoxRemoveNAMA.SelectedIndex = -1; 
            comBoxRemoveNAMA.ValueMember = "ID Produk";

            textBoxRmvHarga.Text = dtMenu.Rows[2].ToString();
            textBoxRmvID.Text = dtMenu.Rows[0].ToString();
            
        }

        private void comBoxRemoveNAMA_SelectedIndexChanged(object sender, EventArgs e)
        {
            foreach(DataRow row in dtMenu.Rows) 
            { 
                if (row[0] == comBoxRemoveNAMA.SelectedValue) 
                { 
                    textBoxRmvHarga.Text = row[2].ToString();
                    textBoxRmvID.Text = row[0].ToString();
                }
            }
        }

        private void buttonRMV_Click(object sender, EventArgs e)
        {

            form1.setDelete(comBoxRemoveNAMA.SelectedValue.ToString());
            this.Close();
        }
    }
}
