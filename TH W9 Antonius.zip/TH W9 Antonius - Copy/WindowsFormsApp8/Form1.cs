﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp8
{
    public partial class Form1 : Form

    {
        DataTable dtCART = new DataTable();
        int x = 0;
        string mantap = "";
        int anzaay = 0;
        

        public Form1()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dtCART.Columns.Add("Item Name");
            dtCART.Columns.Add("Quantity");
            dtCART.Columns.Add("Price" , typeof(int));
            dtCART.Columns.Add("Total");

            dgvCART.DataSource = dtCART;

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("Red Brown T-Shirt", 1, 150000,150000);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();

        }

        private void btnAddShirt2_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("Blue Jeans Long Shirt", 1, 150000,150000);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void btnAddShirt3_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("White Long T-Shirt", 1, 150000, 150000 );
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void btnAddShort1_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("White Short", 1, 150000,150000);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void btnAddShort2_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("Brown Long Pants", 1, 150000, 150000);
                //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void btnAddSHort3_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("Blue Jeans", 1, 150000,150000);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void topWToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelAcc.Visible = false;
            panelBottomWar.Visible = false;
            panelTOPWEAR.Visible = true;
        }

        private void bottomWearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelAcc.Visible = false;
            panelOTHERS.Visible = false;
            panelTOPWEAR.Visible = false;
            panelBottomWar.Visible = true;
        }

        private void accessoriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelOTHERS.Visible = false;
            panelBottomWar.Visible = false;
            panelTOPWEAR.Visible = false;
            panelAcc.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.ShowDialog();
            pictureBoxOTHER.ImageLocation = openFileDialog.FileName;
            x++;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            

            if (x == 1) 
            {
                textBoxOtherName.Enabled = true;
               textBoxOtherPrice.Enabled = true;
                if (textBoxOtherName.Text != "" && textBoxOtherPrice.Text != "")
                {
                    x++;
                }
            }
            if ( x == 2)
            {
                buttonAddOthers.Enabled = true;
            }
           
        }

        private void buttonAddOther_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add(textBoxOtherName.Text.ToString(), 1, textBoxOtherPrice.Text.ToString());
            
        }

        private void txtNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                textBoxOtherPrice.Text = "";
                e.Handled = true;

            }
        }

        private void textBoxOtherPrice_TextChanged(object sender, EventArgs e)
        {
            textBoxOtherPrice.KeyPress += new KeyPressEventHandler(txtNumber_KeyPress);
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panelBottomWar.Visible = false;
            panelTOPWEAR.Visible = false;
            panelAcc.Visible = false;
            panelOTHERS.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add(textBoxOtherName.Text, 1, textBoxOtherPrice.Text);
            x = 0;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("White Shoe", 1, 150000, 150000);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dtCART.Rows.Add("Circle Necklaces", 1, 150000,150000);

            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           


            for (int i = 0; i < dtCART.Rows.Count; i++)
            {
               
                if (dtCART.Rows[i][0] == "Rolex Watch")
                {
                    dtCART.Rows.RemoveAt(i);
                    
                    dtCART.Rows.Add("Rolex Watch", 2, 150000,300000);
                }
                break;


            }
            dtCART.Rows.Add("Rolex Watch", 1, 150000, 150000);

            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void textBoxSubTotal_TextChanged(object sender, EventArgs e)
        {
           
            
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            dgvCART.Rows.RemoveAt(dgvCART.CurrentRow.Index);
            //
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void button5_Click_1(object sender, EventArgs e)
        {
            int sum = dtCART.AsEnumerable().Sum(row => row.Field<int>("Price"));
            int kiw = sum * 1 / 10;
            int piw = sum + kiw;
            textBoxSubTotal.Text = sum.ToString();
            textBoxTOTAL.Text = piw.ToString();
        }

        private void dgvCART_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBoxTOTAL_TextChanged(object sender, EventArgs e)
        {
            
            
        }
    }
}
