﻿namespace WindowsFormsApp8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvCART = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accessoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelTOPWEAR = new System.Windows.Forms.Panel();
            this.btnAddShirt3 = new System.Windows.Forms.Button();
            this.btnAddShirt2 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddShirt1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelBottomWar = new System.Windows.Forms.Panel();
            this.btnAddSHort3 = new System.Windows.Forms.Button();
            this.btnAddShort2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnAddShort1 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panelAcc = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panelOTHERS = new System.Windows.Forms.Panel();
            this.buttonAddOthers = new System.Windows.Forms.Button();
            this.textBoxOtherPrice = new System.Windows.Forms.TextBox();
            this.textBoxOtherName = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBoxOTHER = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.textBoxSubTotal = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxTOTAL = new System.Windows.Forms.TextBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCART)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.panelTOPWEAR.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelBottomWar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panelAcc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panelOTHERS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOTHER)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCART
            // 
            this.dgvCART.AllowUserToAddRows = false;
            this.dgvCART.AllowUserToDeleteRows = false;
            this.dgvCART.AllowUserToResizeColumns = false;
            this.dgvCART.AllowUserToResizeRows = false;
            this.dgvCART.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvCART.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvCART.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCART.Location = new System.Drawing.Point(501, 52);
            this.dgvCART.Name = "dgvCART";
            this.dgvCART.RowHeadersVisible = false;
            this.dgvCART.Size = new System.Drawing.Size(287, 278);
            this.dgvCART.TabIndex = 0;
            this.dgvCART.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCART_CellContentClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accessoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWToolStripMenuItem
            // 
            this.topWToolStripMenuItem.Name = "topWToolStripMenuItem";
            this.topWToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.topWToolStripMenuItem.Text = "Top Wear";
            this.topWToolStripMenuItem.Click += new System.EventHandler(this.topWToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            this.bottomWearToolStripMenuItem.Click += new System.EventHandler(this.bottomWearToolStripMenuItem_Click);
            // 
            // accessoriesToolStripMenuItem
            // 
            this.accessoriesToolStripMenuItem.Name = "accessoriesToolStripMenuItem";
            this.accessoriesToolStripMenuItem.Size = new System.Drawing.Size(80, 20);
            this.accessoriesToolStripMenuItem.Text = "Accessories";
            this.accessoriesToolStripMenuItem.Click += new System.EventHandler(this.accessoriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // panelTOPWEAR
            // 
            this.panelTOPWEAR.Controls.Add(this.btnAddShirt3);
            this.panelTOPWEAR.Controls.Add(this.btnAddShirt2);
            this.panelTOPWEAR.Controls.Add(this.label6);
            this.panelTOPWEAR.Controls.Add(this.label5);
            this.panelTOPWEAR.Controls.Add(this.label4);
            this.panelTOPWEAR.Controls.Add(this.label3);
            this.panelTOPWEAR.Controls.Add(this.label2);
            this.panelTOPWEAR.Controls.Add(this.label1);
            this.panelTOPWEAR.Controls.Add(this.btnAddShirt1);
            this.panelTOPWEAR.Controls.Add(this.pictureBox2);
            this.panelTOPWEAR.Controls.Add(this.pictureBox1);
            this.panelTOPWEAR.Controls.Add(this.pictureBox3);
            this.panelTOPWEAR.Location = new System.Drawing.Point(0, 43);
            this.panelTOPWEAR.Name = "panelTOPWEAR";
            this.panelTOPWEAR.Size = new System.Drawing.Size(495, 375);
            this.panelTOPWEAR.TabIndex = 6;
            this.panelTOPWEAR.Visible = false;
            // 
            // btnAddShirt3
            // 
            this.btnAddShirt3.Location = new System.Drawing.Point(371, 274);
            this.btnAddShirt3.Name = "btnAddShirt3";
            this.btnAddShirt3.Size = new System.Drawing.Size(75, 23);
            this.btnAddShirt3.TabIndex = 17;
            this.btnAddShirt3.Text = "Add to Cart";
            this.btnAddShirt3.UseVisualStyleBackColor = true;
            this.btnAddShirt3.Click += new System.EventHandler(this.btnAddShirt3_Click);
            // 
            // btnAddShirt2
            // 
            this.btnAddShirt2.Location = new System.Drawing.Point(212, 274);
            this.btnAddShirt2.Name = "btnAddShirt2";
            this.btnAddShirt2.Size = new System.Drawing.Size(75, 23);
            this.btnAddShirt2.TabIndex = 16;
            this.btnAddShirt2.Text = "Add to Cart";
            this.btnAddShirt2.UseVisualStyleBackColor = true;
            this.btnAddShirt2.Click += new System.EventHandler(this.btnAddShirt2_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(350, 245);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Rp. 150.000,-";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(177, 245);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Rp. 150.000,-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 245);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Rp. 150.000,-";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(350, 223);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "White Long T-Shirt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(177, 223);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Blue Jeans Long Shirt";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 223);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Red Brown T-Shirt";
            // 
            // btnAddShirt1
            // 
            this.btnAddShirt1.Location = new System.Drawing.Point(31, 274);
            this.btnAddShirt1.Name = "btnAddShirt1";
            this.btnAddShirt1.Size = new System.Drawing.Size(75, 23);
            this.btnAddShirt1.TabIndex = 9;
            this.btnAddShirt1.Text = "Add to Cart";
            this.btnAddShirt1.UseVisualStyleBackColor = true;
            this.btnAddShirt1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::WindowsFormsApp8.Properties.Resources.shirt2;
            this.pictureBox2.Location = new System.Drawing.Point(180, 11);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 196);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp8.Properties.Resources.shirt;
            this.pictureBox1.Location = new System.Drawing.Point(3, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(139, 196);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WindowsFormsApp8.Properties.Resources.shirt3;
            this.pictureBox3.Location = new System.Drawing.Point(353, 11);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(139, 196);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // panelBottomWar
            // 
            this.panelBottomWar.Controls.Add(this.btnAddSHort3);
            this.panelBottomWar.Controls.Add(this.btnAddShort2);
            this.panelBottomWar.Controls.Add(this.label7);
            this.panelBottomWar.Controls.Add(this.label8);
            this.panelBottomWar.Controls.Add(this.label9);
            this.panelBottomWar.Controls.Add(this.label10);
            this.panelBottomWar.Controls.Add(this.label11);
            this.panelBottomWar.Controls.Add(this.label12);
            this.panelBottomWar.Controls.Add(this.btnAddShort1);
            this.panelBottomWar.Controls.Add(this.pictureBox4);
            this.panelBottomWar.Controls.Add(this.pictureBox5);
            this.panelBottomWar.Controls.Add(this.pictureBox6);
            this.panelBottomWar.Location = new System.Drawing.Point(0, 40);
            this.panelBottomWar.Name = "panelBottomWar";
            this.panelBottomWar.Size = new System.Drawing.Size(495, 375);
            this.panelBottomWar.TabIndex = 7;
            this.panelBottomWar.Visible = false;
            // 
            // btnAddSHort3
            // 
            this.btnAddSHort3.Location = new System.Drawing.Point(371, 274);
            this.btnAddSHort3.Name = "btnAddSHort3";
            this.btnAddSHort3.Size = new System.Drawing.Size(75, 23);
            this.btnAddSHort3.TabIndex = 17;
            this.btnAddSHort3.Text = "Add to Cart";
            this.btnAddSHort3.UseVisualStyleBackColor = true;
            this.btnAddSHort3.Click += new System.EventHandler(this.btnAddSHort3_Click);
            // 
            // btnAddShort2
            // 
            this.btnAddShort2.Location = new System.Drawing.Point(212, 274);
            this.btnAddShort2.Name = "btnAddShort2";
            this.btnAddShort2.Size = new System.Drawing.Size(75, 23);
            this.btnAddShort2.TabIndex = 16;
            this.btnAddShort2.Text = "Add to Cart";
            this.btnAddShort2.UseVisualStyleBackColor = true;
            this.btnAddShort2.Click += new System.EventHandler(this.btnAddShort2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(350, 245);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Rp. 150.000,-";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(177, 245);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "Rp. 150.000,-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 245);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 13);
            this.label9.TabIndex = 13;
            this.label9.Text = "Rp. 150.000,-";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(350, 223);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Blue Jeans";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(177, 223);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Brown Long Pants";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 10;
            this.label12.Text = "White Short";
            // 
            // btnAddShort1
            // 
            this.btnAddShort1.Location = new System.Drawing.Point(31, 274);
            this.btnAddShort1.Name = "btnAddShort1";
            this.btnAddShort1.Size = new System.Drawing.Size(75, 23);
            this.btnAddShort1.TabIndex = 9;
            this.btnAddShort1.Text = "Add to Cart";
            this.btnAddShort1.UseVisualStyleBackColor = true;
            this.btnAddShort1.Click += new System.EventHandler(this.btnAddShort1_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::WindowsFormsApp8.Properties.Resources.short2;
            this.pictureBox4.Location = new System.Drawing.Point(180, 11);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(139, 196);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::WindowsFormsApp8.Properties.Resources._short;
            this.pictureBox5.Location = new System.Drawing.Point(3, 11);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(139, 196);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::WindowsFormsApp8.Properties.Resources.short3;
            this.pictureBox6.Location = new System.Drawing.Point(353, 11);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(139, 196);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox6.TabIndex = 8;
            this.pictureBox6.TabStop = false;
            // 
            // panelAcc
            // 
            this.panelAcc.Controls.Add(this.button1);
            this.panelAcc.Controls.Add(this.button2);
            this.panelAcc.Controls.Add(this.label13);
            this.panelAcc.Controls.Add(this.label14);
            this.panelAcc.Controls.Add(this.label15);
            this.panelAcc.Controls.Add(this.label16);
            this.panelAcc.Controls.Add(this.label17);
            this.panelAcc.Controls.Add(this.label18);
            this.panelAcc.Controls.Add(this.button3);
            this.panelAcc.Controls.Add(this.pictureBox7);
            this.panelAcc.Controls.Add(this.pictureBox8);
            this.panelAcc.Controls.Add(this.pictureBox9);
            this.panelAcc.Location = new System.Drawing.Point(0, 37);
            this.panelAcc.Name = "panelAcc";
            this.panelAcc.Size = new System.Drawing.Size(495, 375);
            this.panelAcc.TabIndex = 18;
            this.panelAcc.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(371, 277);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Add to Cart";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(212, 277);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 16;
            this.button2.Text = "Add to Cart";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(350, 248);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Rp. 150.000,-";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(177, 248);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Rp. 150.000,-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 248);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 13);
            this.label15.TabIndex = 13;
            this.label15.Text = "Rp. 150.000,-";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(350, 229);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "Rolex Watch";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(177, 229);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(87, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "Circle Necklaces";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 229);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(63, 13);
            this.label18.TabIndex = 10;
            this.label18.Text = "White Shoe";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(31, 277);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 9;
            this.button3.Text = "Add to Cart";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::WindowsFormsApp8.Properties.Resources.jewel;
            this.pictureBox7.Location = new System.Drawing.Point(180, 15);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(139, 196);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox7.TabIndex = 7;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::WindowsFormsApp8.Properties.Resources.shoe;
            this.pictureBox8.Location = new System.Drawing.Point(3, 15);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(139, 196);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::WindowsFormsApp8.Properties.Resources.watch;
            this.pictureBox9.Location = new System.Drawing.Point(353, 15);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(139, 196);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            // 
            // panelOTHERS
            // 
            this.panelOTHERS.Controls.Add(this.buttonAddOthers);
            this.panelOTHERS.Controls.Add(this.textBoxOtherPrice);
            this.panelOTHERS.Controls.Add(this.textBoxOtherName);
            this.panelOTHERS.Controls.Add(this.label21);
            this.panelOTHERS.Controls.Add(this.label20);
            this.panelOTHERS.Controls.Add(this.button4);
            this.panelOTHERS.Controls.Add(this.label19);
            this.panelOTHERS.Controls.Add(this.pictureBoxOTHER);
            this.panelOTHERS.Location = new System.Drawing.Point(3, 23);
            this.panelOTHERS.Name = "panelOTHERS";
            this.panelOTHERS.Size = new System.Drawing.Size(492, 411);
            this.panelOTHERS.TabIndex = 19;
            this.panelOTHERS.Visible = false;
            this.panelOTHERS.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // buttonAddOthers
            // 
            this.buttonAddOthers.Enabled = false;
            this.buttonAddOthers.Location = new System.Drawing.Point(380, 248);
            this.buttonAddOthers.Name = "buttonAddOthers";
            this.buttonAddOthers.Size = new System.Drawing.Size(75, 23);
            this.buttonAddOthers.TabIndex = 8;
            this.buttonAddOthers.Text = "Add to Cart";
            this.buttonAddOthers.UseVisualStyleBackColor = true;
            this.buttonAddOthers.Click += new System.EventHandler(this.button5_Click);
            // 
            // textBoxOtherPrice
            // 
            this.textBoxOtherPrice.Enabled = false;
            this.textBoxOtherPrice.Location = new System.Drawing.Point(266, 185);
            this.textBoxOtherPrice.Name = "textBoxOtherPrice";
            this.textBoxOtherPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxOtherPrice.TabIndex = 7;
            this.textBoxOtherPrice.TextChanged += new System.EventHandler(this.textBoxOtherPrice_TextChanged);
            // 
            // textBoxOtherName
            // 
            this.textBoxOtherName.Enabled = false;
            this.textBoxOtherName.Location = new System.Drawing.Point(269, 113);
            this.textBoxOtherName.Name = "textBoxOtherName";
            this.textBoxOtherName.Size = new System.Drawing.Size(100, 20);
            this.textBoxOtherName.TabIndex = 6;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(266, 169);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(54, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Item Price";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(265, 96);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(58, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Item Name";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(269, 32);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = " Upload";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(167, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 13);
            this.label19.TabIndex = 1;
            this.label19.Text = "Upload Image :";
            // 
            // pictureBoxOTHER
            // 
            this.pictureBoxOTHER.Location = new System.Drawing.Point(106, 77);
            this.pictureBoxOTHER.Name = "pictureBoxOTHER";
            this.pictureBoxOTHER.Size = new System.Drawing.Size(140, 194);
            this.pictureBoxOTHER.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBoxOTHER.TabIndex = 0;
            this.pictureBoxOTHER.TabStop = false;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Perpetua Titling MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(545, 340);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 13);
            this.label22.TabIndex = 20;
            this.label22.Text = "Sub-Total :";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // textBoxSubTotal
            // 
            this.textBoxSubTotal.Location = new System.Drawing.Point(633, 337);
            this.textBoxSubTotal.Name = "textBoxSubTotal";
            this.textBoxSubTotal.Size = new System.Drawing.Size(100, 20);
            this.textBoxSubTotal.TabIndex = 21;
            this.textBoxSubTotal.TextChanged += new System.EventHandler(this.textBoxSubTotal_TextChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Perpetua Titling MT", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(572, 373);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Total :";
            // 
            // textBoxTOTAL
            // 
            this.textBoxTOTAL.Location = new System.Drawing.Point(633, 370);
            this.textBoxTOTAL.Name = "textBoxTOTAL";
            this.textBoxTOTAL.Size = new System.Drawing.Size(100, 20);
            this.textBoxTOTAL.TabIndex = 23;
            this.textBoxTOTAL.TextChanged += new System.EventHandler(this.textBoxTOTAL_TextChanged);
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(713, 23);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(75, 23);
            this.buttonRemove.TabIndex = 9;
            this.buttonRemove.Text = "Remove";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonRemove);
            this.Controls.Add(this.textBoxTOTAL);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBoxSubTotal);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.panelOTHERS);
            this.Controls.Add(this.panelAcc);
            this.Controls.Add(this.panelBottomWar);
            this.Controls.Add(this.panelTOPWEAR);
            this.Controls.Add(this.dgvCART);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCART)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelTOPWEAR.ResumeLayout(false);
            this.panelTOPWEAR.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelBottomWar.ResumeLayout(false);
            this.panelBottomWar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panelAcc.ResumeLayout(false);
            this.panelAcc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panelOTHERS.ResumeLayout(false);
            this.panelOTHERS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOTHER)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCART;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accessoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panelTOPWEAR;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnAddShirt1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddShirt3;
        private System.Windows.Forms.Button btnAddShirt2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelBottomWar;
        private System.Windows.Forms.Button btnAddSHort3;
        private System.Windows.Forms.Button btnAddShort2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnAddShort1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panelAcc;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panelOTHERS;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBoxOTHER;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxOtherPrice;
        private System.Windows.Forms.TextBox textBoxOtherName;
        private System.Windows.Forms.Button buttonAddOthers;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBoxSubTotal;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBoxTOTAL;
        private System.Windows.Forms.Button buttonRemove;
    }
}

