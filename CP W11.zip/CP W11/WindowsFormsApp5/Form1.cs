﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlconnect;
        MySqlCommand sqlcommand;
        MySqlDataAdapter sqldataadapter;
        DataTable dtstudent = new DataTable();
        String sql = "";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            sqlconnect = new MySqlConnection("server=localhost;uid=root;pwd=isbmantap;database=premier_league");
            

        }
        bool cek = true;
        int id = 1;
        private void buttonPEPE_Click(object sender, EventArgs e)
        {
            sql = "DELETE FROM student;";
            sqlconnect.Open();
            sqlcommand = new MySqlCommand(sql, sqlconnect);
            sqlcommand.ExecuteNonQuery();
            sqlconnect.Close();
            for (int i = 0; i < dtstudent.Rows.Count; i++)
            {
                if (textBoxNIM.Text == dtstudent.Rows[i][3].ToString())
                {

                    cek = false;
                    break;  


                }
               
            }
            if (cek == false)
            {
                MessageBox.Show("GABISA SAYANG NIM SUDAH ADA");
                cek = true; 
            }
            else
            {
                string idd ="";
                if (id < 10)
                {
                    idd = "00";
                    idd = idd + id.ToString();
                    id++;
                }
                else if ( id < 100)
                {
                    idd = "0";
                    idd = idd + id.ToString();
                    id++;
                }
                else
                {
                    idd = "";
                    idd = idd + id.ToString();
                    id++;
                }

                sql = "INSERT INTO student VALUE ('"+idd+"','" + textBoxNAMA.Text + "','2005-01-14','" + textBoxNIM.Text + "')";
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(sql, sqlconnect);
                sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
            }

            
            

            sql = "SELECT * FROM student";
            sqlcommand = new MySqlCommand(sql, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(dtstudent);
            dgvPEPE.DataSource = dtstudent;

        }

        private void dgvPEPE_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            
        }

        private void buttonUPDATE_Click(object sender, EventArgs e)
        {
            dtstudent = new DataTable();

            for (int i = 0; i < dtstudent.Rows.Count; i++)
            {
                if (textBoxNIM.Text == dtstudent.Rows[i][3].ToString())
                {

                    cek = false;
                    break;


                }

            }
            if (cek == false)
            {
                MessageBox.Show("GABISA SAYANG NIM SUDAH ADA");
                cek = true;
            }
            else
            {
                dtstudent.Rows.Clear();
                sql = "UPDATE student SET student_name = '" + textBoxUPDATENAMA.Text + "','student_nim = '" + textBoxUPDATENIM.Text + "' WHERE id_student = '" + dgvPEPE.CurrentRow.Cells[0].Value.ToString();
                sqlconnect.Open();
                sqlcommand = new MySqlCommand(sql, sqlconnect);
                //sqlcommand.ExecuteNonQuery();
                sqlconnect.Close();
            }

            


            sql = "SELECT * FROM student";
            sqlcommand = new MySqlCommand(sql, sqlconnect);
            sqldataadapter = new MySqlDataAdapter(sqlcommand);
            sqldataadapter.Fill(dtstudent);
            dgvPEPE.DataSource = dtstudent;
        }
    }
}
