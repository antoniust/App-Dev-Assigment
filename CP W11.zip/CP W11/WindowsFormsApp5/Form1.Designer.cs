﻿namespace WindowsFormsApp5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxNAMA = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxNIM = new System.Windows.Forms.TextBox();
            this.dgvPEPE = new System.Windows.Forms.DataGridView();
            this.buttonPEPE = new System.Windows.Forms.Button();
            this.buttonUPDATE = new System.Windows.Forms.Button();
            this.textBoxUPDATENIM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBoxUPDATENAMA = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPEPE)).BeginInit();
            this.SuspendLayout();
            // 
            // textBoxNAMA
            // 
            this.textBoxNAMA.Location = new System.Drawing.Point(223, 60);
            this.textBoxNAMA.Name = "textBoxNAMA";
            this.textBoxNAMA.Size = new System.Drawing.Size(158, 31);
            this.textBoxNAMA.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(101, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nama :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(119, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "NIM :";
            // 
            // textBoxNIM
            // 
            this.textBoxNIM.Location = new System.Drawing.Point(223, 111);
            this.textBoxNIM.Name = "textBoxNIM";
            this.textBoxNIM.Size = new System.Drawing.Size(158, 31);
            this.textBoxNIM.TabIndex = 3;
            // 
            // dgvPEPE
            // 
            this.dgvPEPE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPEPE.Location = new System.Drawing.Point(441, 219);
            this.dgvPEPE.Name = "dgvPEPE";
            this.dgvPEPE.RowHeadersWidth = 82;
            this.dgvPEPE.RowTemplate.Height = 33;
            this.dgvPEPE.Size = new System.Drawing.Size(806, 436);
            this.dgvPEPE.TabIndex = 4;
            this.dgvPEPE.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPEPE_CellContentClick);
            // 
            // buttonPEPE
            // 
            this.buttonPEPE.Location = new System.Drawing.Point(204, 185);
            this.buttonPEPE.Name = "buttonPEPE";
            this.buttonPEPE.Size = new System.Drawing.Size(128, 45);
            this.buttonPEPE.TabIndex = 5;
            this.buttonPEPE.Text = "button1";
            this.buttonPEPE.UseVisualStyleBackColor = true;
            this.buttonPEPE.Click += new System.EventHandler(this.buttonPEPE_Click);
            // 
            // buttonUPDATE
            // 
            this.buttonUPDATE.Location = new System.Drawing.Point(185, 490);
            this.buttonUPDATE.Name = "buttonUPDATE";
            this.buttonUPDATE.Size = new System.Drawing.Size(128, 45);
            this.buttonUPDATE.TabIndex = 10;
            this.buttonUPDATE.Text = "UPDATE";
            this.buttonUPDATE.UseVisualStyleBackColor = true;
            this.buttonUPDATE.Click += new System.EventHandler(this.buttonUPDATE_Click);
            // 
            // textBoxUPDATENIM
            // 
            this.textBoxUPDATENIM.Location = new System.Drawing.Point(204, 416);
            this.textBoxUPDATENIM.Name = "textBoxUPDATENIM";
            this.textBoxUPDATENIM.Size = new System.Drawing.Size(158, 31);
            this.textBoxUPDATENIM.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(100, 419);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 25);
            this.label3.TabIndex = 8;
            this.label3.Text = "NIM :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(82, 365);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 25);
            this.label4.TabIndex = 7;
            this.label4.Text = "Nama :";
            // 
            // textBoxUPDATENAMA
            // 
            this.textBoxUPDATENAMA.Location = new System.Drawing.Point(204, 365);
            this.textBoxUPDATENAMA.Name = "textBoxUPDATENAMA";
            this.textBoxUPDATENAMA.Size = new System.Drawing.Size(158, 31);
            this.textBoxUPDATENAMA.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1281, 768);
            this.Controls.Add(this.buttonUPDATE);
            this.Controls.Add(this.textBoxUPDATENIM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBoxUPDATENAMA);
            this.Controls.Add(this.buttonPEPE);
            this.Controls.Add(this.dgvPEPE);
            this.Controls.Add(this.textBoxNIM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxNAMA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPEPE)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxNAMA;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxNIM;
        private System.Windows.Forms.DataGridView dgvPEPE;
        private System.Windows.Forms.Button buttonPEPE;
        private System.Windows.Forms.Button buttonUPDATE;
        private System.Windows.Forms.TextBox textBoxUPDATENIM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBoxUPDATENAMA;
    }
}

